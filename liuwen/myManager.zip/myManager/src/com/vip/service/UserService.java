package com.vip.service;

/**
 * UserService
 * 
 * @author Wen
 * 
 */
public interface UserService {
	

	boolean isExitByUserNameAndPass(String username, String password);
}
